import os
import json
import time
import base64
import hashlib
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

import requests

# =========================
# ENV VARS
# =========================
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "").strip()
GITHUB_REPO = os.getenv("GITHUB_REPO", "").strip()  # "SamuelVdub/StillWaterGrants"
GITHUB_BRANCH = os.getenv("GITHUB_BRANCH", "main").strip()
GITHUB_PATH = os.getenv("GITHUB_PATH", "index.html").strip()

NTFY_TOPIC = os.getenv("NTFY_TOPIC", "Still-Water-Grants-04").strip()
NTFY_URL = f"https://ntfy.sh/{NTFY_TOPIC}"

AI_MODEL = os.getenv("AI_MODEL", "gpt-4.1-mini").strip()

# =========================
# FIXED CONFIG
# =========================
DB_FILE = "grants_db.json"
RUN_STATE_FILE = "run_state.json"
LOCAL_HTML_FILE = "index.html"

RUN_EVERY_SECONDS = 6 * 60 * 60
MAX_AI_PER_RUN = 25
ROWS_PER_PAGE = 100
INCLUDE_FORECASTED = True

SEARCH2_URL = "https://api.grants.gov/v1/api/search2"

PROFILE = """
Business type: For-profit, family-owned commercial greenhouse / nursery
Location: Sanger, Texas (Denton County, North Texas near Denton–Fort Worth)
Size: ~17 acres under glass
Crops: Annuals, tropicals, shrubs, bushes (ornamental horticulture)
Facilities: Pre-existing greenhouse buildings
Labor: May use H-2A
Grant focus: agriculture, greenhouse/nursery/horticulture, energy (solar/efficiency/heating/lighting),
infrastructure/facilities/equipment, land improvement, water/irrigation, conservation/sustainability,
USDA/NRCS/Rural Development, cost-share, loan guarantees, for-profit incentives.
Exclusions: Military-only/DoD-only, scholarships/students, university-only, education-only, nonprofit-only unless for-profit eligible.
""".strip()

# =========================
# WIDE KEYWORDS
# =========================
GRANTS_KEYWORDS = [
    "agriculture", "farm", "farming", "producer", "grower",
    "crop", "specialty crop", "plant production",

    "greenhouse", "commercial greenhouse", "nursery", "plant nursery",
    "horticulture", "ornamental horticulture", "floriculture",
    "protected agriculture", "controlled environment agriculture", "CEA",
    "high tunnel", "hoophouse",

    "equipment", "machinery", "capital improvement", "facilities", "infrastructure",
    "storage", "cold storage", "automation", "modernization",

    "irrigation", "drip irrigation", "water conservation", "water efficiency",
    "stormwater", "drainage", "runoff",

    "conservation", "soil health", "nutrient management", "IPM",
    "sustainability", "resilience", "climate smart",

    "energy efficiency", "renewable energy", "solar", "battery storage",
    "heat pump", "LED lighting", "HVAC",

    "USDA", "NRCS", "FSA", "Rural Development",
    "cost share", "cost-share", "loan guarantee", "financing",

    "H-2A", "workforce", "agricultural labor",

    "Texas",
]

# =========================
# TIME / HASH / LINKS
# =========================
def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def stable_hash(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()[:16]

def grant_link(grant_id: str) -> str:
    return f"https://www.grants.gov/search-results-detail/{grant_id}"

# =========================
# DB LOAD/SAVE
# =========================
def load_json_file(path: str, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json_file(path: str, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)

def load_db() -> Dict[str, Any]:
    db = load_json_file(DB_FILE, {})
    if not isinstance(db, dict):
        db = {}
    return db

def save_db(db: Dict[str, Any]):
    save_json_file(DB_FILE, db)

def load_run_state() -> Dict[str, Any]:
    state = load_json_file(RUN_STATE_FILE, {"first_run_done": False})
    if not isinstance(state, dict):
        state = {"first_run_done": False}
    if "first_run_done" not in state:
        state["first_run_done"] = False
    return state

def save_run_state(state: Dict[str, Any]):
    save_json_file(RUN_STATE_FILE, state)

# =========================
# NTFY (NON-FATAL)
# =========================
def ntfy_send(title: str, message: str, priority: str = "3", tags: Optional[List[str]] = None, click_url: Optional[str] = None) -> bool:
    headers = {"Title": title, "Priority": str(priority)}
    if tags:
        headers["Tags"] = ",".join(tags)
    if click_url:
        headers["Click"] = click_url
    try:
        r = requests.post(NTFY_URL, data=message.encode("utf-8"), headers=headers, timeout=20)
        print("ntfy:", r.status_code)
        return 200 <= r.status_code < 300
    except requests.RequestException as e:
        print("ntfy failed (non-fatal):", repr(e))
        return False

# =========================
# HARD NO (NO AI)
# =========================
def hard_no_reason(title: str, agency: str, synopsis: str) -> Optional[str]:
    text = f"{title}\n{agency}\n{synopsis}".lower()

    # obvious disqualifiers
    bad_phrases = [
        "department of defense", "dod", "navy", "air force", "army", "marine corps",
        "missile", "munitions", "weapons",
        "scholarship", "fellowship", "students only", "student",
        "institutions of higher education only", "university only",
        "k-12", "school district",
    ]
    for b in bad_phrases:
        if b in text:
            return f"Hard NO: matched '{b}'."

    # nonprofit-only unless it explicitly mentions for-profit/small business eligibility
    if "nonprofit" in text and ("for-profit" not in text and "for profit" not in text and "small business" not in text and "business" not in text):
        return "Hard NO: nonprofit-only language (no for-profit path mentioned)."

    return None

# =========================
# GRANTS.GOV FETCH (PAGINATION)
# =========================
def fetch_search2_all_pages(keyword: str, rows: int = 100) -> List[Dict[str, Any]]:
    all_hits: List[Dict[str, Any]] = []
    start = 0
    hit_count = None

    while True:
        payload = {
            "keyword": keyword,
            "rows": rows,
            "startRecordNum": start,
            "oppStatuses": "forecasted|posted" if INCLUDE_FORECASTED else "posted",
        }
        r = requests.post(SEARCH2_URL, json=payload, timeout=60)
        r.raise_for_status()
        resp = r.json()
        data = resp.get("data") or {}

        if hit_count is None:
            hit_count = int(data.get("hitCount") or 0)

        hits = data.get("oppHits") or []
        all_hits.extend(hits)

        start += rows
        if start >= (hit_count or 0):
            break

        time.sleep(0.1)

    return all_hits

def fetch_all_keywords_dedupe(keywords: List[str]) -> Dict[str, Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for kw in keywords:
        kw = (kw or "").strip()
        if not kw:
            continue
        hits = fetch_search2_all_pages(kw, rows=ROWS_PER_PAGE)
        for h in hits:
            gid = str(h.get("id") or "").strip()
            if gid:
                merged[gid] = h
    return merged

# =========================
# AI DECISION (STRICT OUTPUT)
# =========================
def ai_decide(title: str, agency: str, synopsis: str) -> Tuple[str, str]:
    """
    Returns (decision, reason) where decision in {"YES","MAYBE","NO"}.
    """
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not set")

    from openai import OpenAI
    client = OpenAI(api_key=OPENAI_API_KEY)

    prompt = f"""
You are screening grants for relevance to a business.

BUSINESS PROFILE:
{PROFILE}

GRANT:
Title: {title}
Agency: {agency}
Synopsis: {synopsis}

RULES:
- Output decision: YES, MAYBE, or NO.
- Prefer false MAYBE over false NO.
- NO if clearly military/DoD-only, scholarship/students-only, university-only, education-only, nonprofit-only with no for-profit path.
- YES if a for-profit commercial greenhouse/nursery could realistically apply or benefit (grant, cost-share, incentive, loan guarantee, etc.).
- MAYBE if uncertain eligibility or indirect fit.

Return valid JSON ONLY:
{{"decision":"YES|MAYBE|NO","reason":"<short reason>"}}
""".strip()

    resp = client.chat.completions.create(
        model=AI_MODEL,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=150,
    )
    raw = (resp.choices[0].message.content or "").strip()

    try:
        obj = json.loads(raw)
        dec = str(obj.get("decision", "")).strip().upper()
        reason = str(obj.get("reason", "")).strip()
        if dec not in ("YES", "MAYBE", "NO"):
            raise ValueError("bad decision")
        if not reason:
            reason = "No reason provided."
        return dec, reason
    except Exception:
        # fallback: don’t lose opportunity -> MAYBE
        return "MAYBE", f"AI parse fallback. Raw: {raw[:140]}"

# =========================
# DASHBOARD HTML (NO PYTHON F-STRING JS)
# =========================
def build_dashboard_html(run_iso: str, records: List[Dict[str, Any]], unique_found: int, ai_on: bool) -> str:
    data_json = json.dumps(records)

    html = """<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Still Water Grants</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 18px; }
    h1 { margin: 0 0 10px 0; font-size: 40px; }
    .meta { display:flex; flex-wrap:wrap; gap:10px; margin: 10px 0 18px; }
    .pill { display:inline-block; padding:6px 10px; border-radius:999px; background:#eee; font-size:13px; }
    .controls { display:flex; flex-wrap:wrap; gap:10px; margin: 10px 0 16px; }
    input, select { padding:10px; font-size:14px; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 10px; font-size: 14px; vertical-align: top; }
    th { background: #f4f4f4; text-align: left; position: sticky; top: 0; z-index: 1; }
    tr:hover { background: #fafafa; }
    a { text-decoration: none; }
    .tag { display:inline-block; padding:2px 8px; border-radius:999px; background:#eee; font-size:12px; }
    .yes { background:#d9f8d9; }
    .maybe { background:#fff2c6; }
    .no { background:#ffd6d6; }
    .small { color:#666; font-size:12px; }
    .countbar { margin: 10px 0 14px; font-weight:bold; }
  </style>
</head>
<body>
  <h1>Still Water Grants</h1>

  <div class="meta">
    <span class="pill">Last run (UTC): __RUN__</span>
    <span class="pill">Keywords: __KW__</span>
    <span class="pill">Unique found (this run): __FOUND__</span>
    <span class="pill">Checked stored: __STORED__</span>
    <span class="pill">AI: __AI__</span>
  </div>

  <div class="controls">
    <input id="q" placeholder="Search title/agency/reason..." style="min-width:260px; flex:1;" />
    <select id="decision">
      <option value="ALL">Decision: ALL</option>
      <option value="YES">Decision: YES</option>
      <option value="MAYBE">Decision: MAYBE</option>
      <option value="NO">Decision: NO</option>
    </select>
    <select id="status">
      <option value="ALL">Status: ALL</option>
      <option value="posted">Status: posted</option>
      <option value="forecasted">Status: forecasted</option>
    </select>
    <select id="sort">
      <option value="deadline_asc">Sort: Deadline (soonest)</option>
      <option value="deadline_desc">Sort: Deadline (latest)</option>
      <option value="first_seen_desc">Sort: First seen (newest)</option>
      <option value="decision">Sort: Decision (YES→MAYBE→NO)</option>
      <option value="title">Sort: Title (A→Z)</option>
    </select>
  </div>

  <div class="countbar" id="counts"></div>

  <table>
    <thead>
      <tr>
        <th>Decision</th>
        <th>Title</th>
        <th>Agency</th>
        <th>Status</th>
        <th>Deadline</th>
        <th>Reason</th>
        <th>First seen</th>
        <th>Last seen</th>
      </tr>
    </thead>
    <tbody id="rows"></tbody>
  </table>

<script>
const DATA = __DATA__;

function decisionRank(d) {
  if (d === "YES") return 0;
  if (d === "MAYBE") return 1;
  return 2;
}
function parseDeadline(s) {
  if (!s) return 0;
  const t = Date.parse(s);
  return isNaN(t) ? 0 : t;
}
function textMatch(item, q) {
  if (!q) return true;
  const hay = ((item.title||"") + " " + (item.agency||"") + " " + (item.reason||"")).toLowerCase();
  return hay.indexOf(q.toLowerCase()) !== -1;
}
function render() {
  const q = document.getElementById("q").value.trim();
  const decision = document.getElementById("decision").value;
  const status = document.getElementById("status").value;
  const sort = document.getElementById("sort").value;

  let filtered = DATA.filter(x => textMatch(x, q));

  if (decision !== "ALL") filtered = filtered.filter(x => (x.decision||"") === decision);
  if (status !== "ALL") filtered = filtered.filter(x => (String(x.status||"").toLowerCase() === status));

  if (sort === "deadline_asc") filtered.sort((a,b) => parseDeadline(a.deadline) - parseDeadline(b.deadline));
  else if (sort === "deadline_desc") filtered.sort((a,b) => parseDeadline(b.deadline) - parseDeadline(a.deadline));
  else if (sort === "first_seen_desc") filtered.sort((a,b) => String(b.first_seen||"").localeCompare(String(a.first_seen||"")));
  else if (sort === "decision") filtered.sort((a,b) => decisionRank(a.decision) - decisionRank(b.decision));
  else if (sort === "title") filtered.sort((a,b) => String(a.title||"").localeCompare(String(b.title||"")));

  let yes=0, maybe=0, no=0;
  filtered.forEach(x => { if (x.decision==="YES") yes++; else if (x.decision==="MAYBE") maybe++; else no++; });

  document.getElementById("counts").textContent =
    "Showing " + filtered.length + " | YES: " + yes + " | MAYBE: " + maybe + " | NO: " + no;

  const tbody = document.getElementById("rows");
  tbody.innerHTML = "";

  filtered.forEach(x => {
    const tr = document.createElement("tr");

    const badge = document.createElement("span");
    badge.className = "tag " + (x.decision==="YES" ? "yes" : (x.decision==="MAYBE" ? "maybe" : "no"));
    badge.textContent = x.decision || "NO";

    const td0 = document.createElement("td");
    td0.appendChild(badge);
    tr.appendChild(td0);

    const td1 = document.createElement("td");
    const a = document.createElement("a");
    a.href = x.link || "#";
    a.target = "_blank";
    a.textContent = x.title || "(Untitled)";
    td1.appendChild(a);
    const small = document.createElement("div");
    small.className = "small";
    small.textContent = x.id || "";
    td1.appendChild(small);
    tr.appendChild(td1);

    const td2 = document.createElement("td"); td2.textContent = x.agency || ""; tr.appendChild(td2);
    const td3 = document.createElement("td"); td3.textContent = x.status || ""; tr.appendChild(td3);
    const td4 = document.createElement("td"); td4.textContent = x.deadline || ""; tr.appendChild(td4);
    const td5 = document.createElement("td"); td5.textContent = x.reason || ""; tr.appendChild(td5);
    const td6 = document.createElement("td"); td6.textContent = x.first_seen || ""; tr.appendChild(td6);
    const td7 = document.createElement("td"); td7.textContent = x.last_seen || ""; tr.appendChild(td7);

    tbody.appendChild(tr);
  });
}

["q","decision","status","sort"].forEach(id => {
  document.getElementById(id).addEventListener("input", render);
  document.getElementById(id).addEventListener("change", render);
});
render();
</script>

</body>
</html>
"""
    html = html.replace("__RUN__", run_iso)
    html = html.replace("__KW__", str(len(GRANTS_KEYWORDS)))
    html = html.replace("__FOUND__", str(unique_found))
    html = html.replace("__STORED__", str(len(records)))
    html = html.replace("__AI__", "ON" if ai_on else "OFF")
    html = html.replace("__DATA__", data_json)
    return html

# =========================
# GITHUB PUSH
# =========================
def push_to_github(html_content: str) -> bool:
    if not GITHUB_TOKEN or not GITHUB_REPO:
        print("GitHub push skipped (missing token/repo).")
        return False

    api = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{GITHUB_PATH}"
    headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github+json"}

    sha = None
    g = requests.get(api, headers=headers, params={"ref": GITHUB_BRANCH}, timeout=30)
    if g.status_code == 200:
        sha = g.json().get("sha")

    content_b64 = base64.b64encode(html_content.encode("utf-8")).decode("utf-8")
    body = {"message": "Update Still Water Grants dashboard", "content": content_b64, "branch": GITHUB_BRANCH}
    if sha:
        body["sha"] = sha

    p = requests.put(api, headers=headers, json=body, timeout=30)
    print("GitHub push:", p.status_code)
    if p.status_code in (200, 201):
        return True
    print("GitHub error:", p.text[:600])
    return False

# =========================
# ONE RUN
# =========================
def run_once():
    run_iso = now_iso()
    db = load_db()
    state = load_run_state()

    # 1) Fetch wide net + dedupe
    merged = fetch_all_keywords_dedupe(GRANTS_KEYWORDS)
    unique_found = len(merged)
    print("Unique found this run:", unique_found)

    # 2) Upsert into DB as "known", update last_seen always
    for gid, opp in merged.items():
        title = (opp.get("title") or "Untitled").strip()
        agency = (opp.get("agencyName") or "").strip()
        status = (opp.get("oppStatus") or "").strip()
        deadline = (opp.get("closeDate") or "").strip()
        synopsis = (opp.get("synopsis") or opp.get("description") or "").strip()

        syn_hash = stable_hash(title + "|" + agency + "|" + synopsis)

        if gid not in db or not isinstance(db.get(gid), dict):
            db[gid] = {
                "id": gid,
                "title": title,
                "agency": agency,
                "status": status,
                "deadline": deadline,
                "synopsis": synopsis,
                "syn_hash": syn_hash,
                "link": grant_link(gid),
                "first_seen": run_iso,
                "last_seen": run_iso,

                # decision fields (only meaningful when checked==True)
                "checked": False,
                "checked_via": "",
                "decision": "",
                "reason": "",
                "notified": False,
            }
        else:
            rec = db[gid]
            rec["title"] = title
            rec["agency"] = agency
            rec["status"] = status
            rec["deadline"] = deadline
            rec["synopsis"] = synopsis
            rec["syn_hash"] = syn_hash
            rec["link"] = grant_link(gid)
            rec["last_seen"] = run_iso

    # 3) Decide which grants to evaluate this run (unchecked only)
    unchecked_ids = [gid for gid, rec in db.items() if isinstance(rec, dict) and rec.get("checked") is False]
    unchecked_ids.sort()  # stable progress

    ai_used = 0
    checked_this_run = 0
    yes_maybe_alerts = 0

    first_run_done = bool(state.get("first_run_done"))
    allow_spam = first_run_done  # No spam on first run

    for gid in unchecked_ids:
        rec = db[gid]
        title = rec.get("title", "")
        agency = rec.get("agency", "")
        synopsis = rec.get("synopsis", "")

        # Hard NO first (counts as checked)
        hard = hard_no_reason(title, agency, synopsis)
        if hard:
            rec["checked"] = True
            rec["checked_via"] = "hard_no"
            rec["decision"] = "NO"
            rec["reason"] = hard
            rec["notified"] = True
            checked_this_run += 1
            continue

        # AI cap
        if ai_used >= MAX_AI_PER_RUN:
            break

        # AI evaluate
        if not OPENAI_API_KEY:
            # AI is required to mark checked (per your rules). If no key, leave unchecked.
            continue

        dec, reason = ai_decide(title, agency, synopsis)
        ai_used += 1

        rec["checked"] = True
        rec["checked_via"] = "ai"
        rec["decision"] = dec
        rec["reason"] = reason
        checked_this_run += 1

        # Notify only for AI-evaluated YES/MAYBE, and only after first run
        if dec in ("YES", "MAYBE"):
            if allow_spam and not rec.get("notified", False):
                link = rec.get("link", "")
                priority = "4" if dec == "YES" else "3"
                ntfy_send(
                    title=f"Still Water Grants ({dec})",
                    message=f"{dec}: {reason}\n\n{title}\nAgency: {agency}\nDeadline: {rec.get('deadline','')}\n{link}",
                    priority=priority,
                    tags=["seedling"] if dec == "YES" else ["mag"],
                    click_url=link,
                )
                rec["notified"] = True
                yes_maybe_alerts += 1
            else:
                # mark as notified to prevent retro spam later
                rec["notified"] = True
        else:
            rec["notified"] = True

        time.sleep(0.05)

    # mark first run done after completing first pass
    if not first_run_done:
        state["first_run_done"] = True

    # 4) Save DB
    save_db(db)
    save_run_state(state)

    # 5) Build dashboard from CHECKED grants only
    records = []
    for gid, rec in db.items():
        if not isinstance(rec, dict):
            continue
        if rec.get("checked") is not True:
            continue
        records.append({
            "id": rec.get("id", ""),
            "title": rec.get("title", ""),
            "agency": rec.get("agency", ""),
            "status": rec.get("status", ""),
            "deadline": rec.get("deadline", ""),
            "decision": rec.get("decision", "NO"),
            "reason": rec.get("reason", ""),
            "link": rec.get("link", ""),
            "first_seen": rec.get("first_seen", ""),
            "last_seen": rec.get("last_seen", ""),
        })

    # stable sort for file output
    records.sort(key=lambda x: (x.get("decision",""), x.get("deadline",""), x.get("title","")))

    html = build_dashboard_html(run_iso, records, unique_found=unique_found, ai_on=bool(OPENAI_API_KEY))
    with open(LOCAL_HTML_FILE, "w", encoding="utf-8") as f:
        f.write(html)

    pushed = push_to_github(html)

    # 6) Heartbeat summary (always OK)
    ntfy_send(
        title="Still Water Grants",
        message=(
            f"Run complete (UTC {run_iso}).\n"
            f"Unique found: {unique_found}\n"
            f"Unchecked remaining: {len([1 for r in db.values() if isinstance(r, dict) and r.get('checked') is False])}\n"
            f"Checked this run: {checked_this_run}\n"
            f"AI used: {ai_used}/{MAX_AI_PER_RUN}\n"
            f"YES/MAYBE alerts sent: {yes_maybe_alerts} (spam={'ON' if allow_spam else 'OFF'})\n"
            f"GitHub push: {'YES' if pushed else 'NO'}"
        ),
        priority="2",
        tags=["white_check_mark"] if pushed else ["warning"],
    )

# =========================
# MAIN LOOP
# =========================
def main():
    print("Starting loop. Runs every 6 hours.")
    while True:
        try:
            run_once()
        except Exception as e:
            # never die
            ntfy_send(
                title="Still Water Grants (Error)",
                message=f"ERROR: {type(e).__name__}: {e}",
                priority="5",
                tags=["rotating_light"],
            )
            print("Error:", repr(e))

        print(f"Sleeping {RUN_EVERY_SECONDS} seconds...")
        time.sleep(RUN_EVERY_SECONDS)

if __name__ == "__main__":
    main()
